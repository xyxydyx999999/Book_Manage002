﻿using JoyfulHome.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace JoyfulHome.Controllers
{
    public class UserController : Controller
    {
        private FreshliveContext db;
        public UserController(FreshliveContext _db) 
        {
            db = _db;
        }
        public IActionResult Index(string name,string text)
        {
            List<Commodity> com_list = db.Commodity.Where(cc => cc.Cstate == "Already on the shelves").OrderByDescending(cc => cc.Id).ToList();
            if (name != null)
            {
                com_list = com_list.Where(cc => cc.Cname.Contains(name)).ToList();
            }
            if (text != null & text != "all")
            {
                com_list = com_list.Where(cc => cc.PName == text).ToList();
            }
            ViewBag.list = com_list;
            ViewBag.type = db.Commodity.Select(uu => uu.PName).Distinct().ToList();


            return View();
        }

        public IActionResult addlike(int id) // add to cart method
        {
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // Get user id

            //UserInfo user = db.UserInfo.Find(userid); // Get the user information

            Commodity com = db.Commodity.Find(id); //  get commodity info

            Shoppingcart shopp = db.Shoppingcart.Where(ss => ss.Cid == id && ss.UId == userid).FirstOrDefault(); // Get the instance of the shopping cart
            if (com.Cinventory <= 0)
            {
                return Content("false"); 
            }
            if (shopp != null) // Determine if it's the first time we've added to the cart If it's not equal to null, it's obviously not, so we just change the number of orders placed
            {
                shopp.Sxdnumber += 1;
                db.SaveChanges();
                return Content("Rejoin the book frame"); // Add the cart again
            }
            else
            {
                shopp = new Shoppingcart();
                shopp.Cid = id; // product id
                shopp.UId = userid; // userid
                shopp.Sname = com.Cname;
                shopp.Sprice = com.Cprice;
                shopp.Simg= com.Cimg;
                shopp.Sxdnumber = 1;
                shopp.Sdate = DateTime.Now; // get the current time
                db.Shoppingcart.Add(shopp);
                db.SaveChanges();
                return Content("Added to the book frame successfully");//Add to the book frame successfully
            }
        }
        // Shopping cart page
        public ActionResult Shoppingcart()
        {
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // get userid
            List<Shoppingcart> shoplist = db.Shoppingcart.Where(ss => ss.UId == userid).ToList();
            ViewBag.list = shoplist;
            ViewBag.summoney = shoplist.Sum(ss => ss.Sprice * ss.Sxdnumber);
            return View();
        }
        public IActionResult jia(int id)
        {
            Shoppingcart shopp = db.Shoppingcart.Find(id); // Get the object product of the shopping cart table
            Commodity com = db.Commodity.Find(shopp.Cid); // Get the object of the product
            {
                return Content("false");
            }
            shopp.Sxdnumber += 1;
            db.SaveChanges();
            return Content("true");
        }
        public IActionResult jian(int id)
        {
            Shoppingcart shopp = db.Shoppingcart.Find(id);
            if (shopp.Sxdnumber == 1)
            {
                db.Shoppingcart.Remove(shopp);
            }
            else
            {
                shopp.Sxdnumber -= 1;
            }
            db.SaveChanges();
            return Redirect("/User/Shoppingcart");
        }
        public IActionResult del(int id)
        {
            Shoppingcart shopp = db.Shoppingcart.Find(id);
            db.Shoppingcart.Remove(shopp);
            db.SaveChanges();
            return Redirect("/User/Shoppingcart");
        }

        // Checkout orders
        public ActionResult jiesuan()
        {
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // get userid

            // Add a limit on how many books can be borrowed
            int shopp_count = int.Parse(db.Shoppingcart.Where(ss => ss.UId == userid).ToList().Sum(oo => oo.Sxdnumber).ToString()); // Get the number of orders placed in the current shopping cart
            int historicalorders_number_count = int.Parse(db.Historicalorders.Where(hh => hh.Uid == userid && hh.Bookreturntime == null).ToList().Sum(oo => oo.Hxdnumber).ToString());
            
            int Summary = shopp_count + historicalorders_number_count; //  Shelf borrowed books and historical borrowed books combined if the returned book is more than 5 books can not be borrowed

            if (Summary > 5)
            {
                return Content("false2");
            }

            UserInfo user = db.UserInfo.Find(userid); // Get the user information

            if (user.Addresss == null)
            {
                return Content("false");
            }

            Orderhistory order = new Orderhistory();
            db.Orderhistory.Add(order);
            db.SaveChanges();

            Orderhistory order_last = db.Orderhistory.ToList().LastOrDefault();
            order_last.Onumber = 0;
            order_last.Osummoney = 0;

            List<Shoppingcart> shopp_list = db.Shoppingcart.Where(ss => ss.UId == userid).ToList();

            foreach (var item in shopp_list)
            {
                Historicalorders hoder = new Historicalorders();
                hoder.Cid = item.Cid;
                hoder.Oid = order_last.Id;
                hoder.Hname = item.Sname;
                hoder.Hprice = item.Sprice;
                hoder.Himg = item.Simg;
                hoder.Hxdnumber = item.Sxdnumber;
                hoder.Uid = userid;
                order_last.Osummoney += decimal.Parse((item.Sxdnumber * item.Sprice).ToString());
                order_last.Onumber += item.Sxdnumber;

                Commodity temp_comm = db.Commodity.Find(item.Cid);
                temp_comm.Cinventory -= item.Sxdnumber;

                db.Historicalorders.Add(hoder);
                db.Shoppingcart.Remove(item);
            }

            order_last.Odate = DateTime.Now;
            order_last.Ostate = "not shipped";
            order_last.UId = userid;
            order_last.Oaddress = user.Addresss;

            db.SaveChanges();
            return Content("The operation was successful");
        }

        // Purchase history page
        public ActionResult Purchasehistory(int? oid)
        {
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // get userid

            List<Orderhistory> list_order = db.Orderhistory.Where(oo => oo.UId == userid).ToList(); //get all the orders for that user

            List<Historicalorders> list_historder = db.Historicalorders.Where(hh => hh.Uid == userid).ToList(); //get all orders purchased by that user

            if (oid != null) // not equal to NULL means a value has been passed in and we have to take the next step
            {
                list_historder = db.Historicalorders.Where(hh => hh.Oid == oid).ToList();
            }

            ViewBag.list_order = list_order.OrderByDescending(oo => oo.Odate).ToList();
            ViewBag.list_historder = list_historder;

            return View();
        }
        // PersonalInformation  PersonalInformation page
        public ActionResult PersonalInformation(string add1, string add2, string add3, UserInfo temp_user)
        {
            if (HttpContext.Session.GetString("userid") == null)
            {
                return Redirect("/Login/Login");
            }

            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // get userid

            if (add1 != null)
            {
                UserInfo user = db.UserInfo.Find(userid);
                user.Addresss = add1 + "," + add2 + "," + add3 + ",Australia";
                user.FullName = temp_user.FirstName + " " + temp_user.LastName;
                user.FirstName = temp_user.FirstName;
                user.LastName = temp_user.LastName;
                user.Email = temp_user.Email;
                
                db.SaveChanges();
                ViewData["msg"] = "ok";
            }

            ArrayList zhou_list = new ArrayList() 
            { "New South Wales (NSW)", "Victoria (VIC)", "Queensland (QLD)",
            "QueenslanWestern Australia (WA)","South Australia (SA)","Tasmania (TAS)","Callaghan(NsW)"};

            ViewBag.user = db.UserInfo.Find(userid); // Get user information
            ViewBag.zhou_list = zhou_list;

            return View();
        }
        public ActionResult UpdatePassword()
        {
            ViewData["msg"] = "null";
            return View();
        }
        [HttpPost]
        public ActionResult UpdatePassword(string pwd1,string pwd2)
        {
            if (pwd1 != pwd2)
            {
                ViewData["msg"] = "no";
                return View();
            }
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // Get userid
            UserInfo user = db.UserInfo.Find(userid);
            user.PassWords= pwd1;
            db.SaveChanges();
            ViewData["msg"] = "ok";
            return View();
        }
        //Functions for the user to receive the goods
        public ActionResult Sh(int id)
        {
            try
            {
                Orderhistory orderhistory = db.Orderhistory.Find(id);
                orderhistory.Ostate = "Received";
                db.SaveChanges();
                return Content("ok");
            }
            catch (Exception)
            {
                return Content("no");
                throw;
            }
        }

    }
}


