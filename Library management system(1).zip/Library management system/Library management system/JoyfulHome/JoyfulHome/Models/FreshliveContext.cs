﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace JoyfulHome.Models
{
    public partial class FreshliveContext : DbContext
    {
        public FreshliveContext()
        {
        }

        public FreshliveContext(DbContextOptions<FreshliveContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Commodity> Commodity { get; set; }
        public virtual DbSet<Historicalorders> Historicalorders { get; set; }
        public virtual DbSet<Orderhistory> Orderhistory { get; set; }
        public virtual DbSet<ProductType> ProductType { get; set; }
        public virtual DbSet<Shoppingcart> Shoppingcart { get; set; }
        public virtual DbSet<UserInfo> UserInfo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=LAPTOP-TVEJNSNP\\SQLEXPRESS1;Initial Catalog=JoyfulHome_book; Integrated Security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Commodity>(entity =>
            {
                entity.Property(e => e.Cimg)
                    .HasColumnName("CImg")
                    .HasMaxLength(200);

                entity.Property(e => e.Cinventory).HasColumnName("CInventory");

                entity.Property(e => e.Cname)
                    .HasColumnName("CName")
                    .HasMaxLength(50);

                entity.Property(e => e.Cprice)
                    .HasColumnName("CPrice")
                    .HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Cstate)
                    .HasColumnName("CState")
                    .HasMaxLength(20);

                entity.Property(e => e.PName)
                    .HasColumnName("P_name")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<Historicalorders>(entity =>
            {
                entity.Property(e => e.Cid).HasColumnName("CId");

                entity.Property(e => e.Himg)
                    .HasColumnName("HImg")
                    .HasMaxLength(200);

                entity.Property(e => e.Hname)
                    .HasColumnName("HName")
                    .HasMaxLength(50);

                entity.Property(e => e.Hprice)
                    .HasColumnName("HPrice")
                    .HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Hxdnumber).HasColumnName("HXdnumber");

                entity.Property(e => e.Oid).HasColumnName("OId");
            });

            modelBuilder.Entity<Orderhistory>(entity =>
            {
                entity.Property(e => e.Oaddress)
                    .HasColumnName("OAddress")
                    .HasMaxLength(500);

                entity.Property(e => e.Odate).HasColumnType("datetime");

                entity.Property(e => e.Ostate).HasMaxLength(30);

                entity.Property(e => e.Osummoney)
                    .HasColumnName("OSummoney")
                    .HasColumnType("decimal(10, 2)");

                entity.Property(e => e.UId).HasColumnName("U_id");
            });

            modelBuilder.Entity<ProductType>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.PName)
                    .HasColumnName("P_name")
                    .HasMaxLength(30);
            });

            modelBuilder.Entity<Shoppingcart>(entity =>
            {
                entity.Property(e => e.Cid).HasColumnName("CId");

                entity.Property(e => e.Sdate).HasColumnType("datetime");

                entity.Property(e => e.Simg)
                    .HasColumnName("SImg")
                    .HasMaxLength(200);

                entity.Property(e => e.Sname)
                    .HasColumnName("SName")
                    .HasMaxLength(50);

                entity.Property(e => e.Sprice)
                    .HasColumnName("SPrice")
                    .HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Sxdnumber).HasColumnName("SXdnumber");

                entity.Property(e => e.UId).HasColumnName("U_id");
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.Property(e => e.Addresss).HasMaxLength(500);

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.FirstName).HasMaxLength(50);

                entity.Property(e => e.FullName).HasMaxLength(50);

                entity.Property(e => e.Identitys).HasMaxLength(50);

                entity.Property(e => e.LastName).HasMaxLength(50);

                entity.Property(e => e.PassWords).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
