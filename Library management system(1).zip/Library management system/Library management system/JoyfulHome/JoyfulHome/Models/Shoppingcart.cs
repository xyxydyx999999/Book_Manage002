﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace JoyfulHome.Models
{
    public partial class Shoppingcart
    {
        public int Id { get; set; }
        public int? Cid { get; set; }
        public int? UId { get; set; }
        public string Sname { get; set; }
        public decimal? Sprice { get; set; }
        public string Simg { get; set; }
        public int? Sxdnumber { get; set; }
        public DateTime? Sdate { get; set; }
    }
}
