﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace JoyfulHome.Models
{
    public partial class Orderhistory
    {
        public int Id { get; set; }
        public int? UId { get; set; }
        public decimal? Osummoney { get; set; }
        public DateTime? Odate { get; set; }
        public string Oaddress { get; set; }
        public int? Onumber { get; set; }
        public string Ostate { get; set; }
    }
}
