﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace JoyfulHome.Models
{
    public partial class Historicalorders
    {
        public int Id { get; set; }
        public int? Cid { get; set; }
        public int? Oid { get; set; }
        public string Hname { get; set; }
        public decimal? Hprice { get; set; }
        public string Himg { get; set; }
        public int? Hxdnumber { get; set; }
        public int? Uid { get; set; }
        public DateTime? Bookreturntime { get; set; }
    }
}
