﻿using JoyfulHome.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Xml.Linq;

namespace JoyfulHome.Controllers
{
    public class ManageController : Controller
    {
        private FreshliveContext db;
        public ManageController(FreshliveContext _db)
        {
            db = _db;
        }
        public IActionResult Index(string name, int PageIndex = 1, int PageSize = 5) // product management page
        {
            var Result = db.Commodity.Where(nn => nn.Cname.Contains(name)).ToList();
            //Save the paging data to the page
            int TotalRows = db.Commodity.Count();
            if (name != null && name != "")
            {
                Result = Result
               .OrderBy(a => a.Id) //ordering criteria
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return the specified number of results
               .ToList();
                //Save the paging data to the page
                TotalRows = Result.Count();
            }
            else
            {
                Result = db.Commodity
               .OrderBy(a => a.Id) //ordering criteria
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return the specified number of results
               .ToList();
            }

            ViewBag.PageIndex = PageIndex;
            ViewBag.PageSize = PageSize;
            ViewBag.TotalRows = TotalRows;
            ViewBag.TotalPage = Math.Ceiling(TotalRows * 1.0 / PageSize);

            ViewBag.list = Result;
            return View();
        }
        public ActionResult Commodity_Add() // Commodity Add
        {
            ViewBag.producttype = db.ProductType.ToList();
            return View();
        }
        [HttpPost]
        public ActionResult Commodity_Add(Commodity com, IFormFile img)
        {
            try
            {
                com.Cstate = "已上架";
                com.Cprice = 1;
                if (img.FileName.Length > 0)
                {
                    com.Cimg = "/Img/" + img.FileName;
                    SaveImage(img);
                }

                db.Commodity.Add(com);
                db.SaveChanges();
                ViewData["msg"] = "ok";
                ViewBag.producttype = db.ProductType.ToList();
            }
            catch (System.Exception)
            {
                ViewData["msg"] = "no";
                throw;
            }
            return View();
        }
        public void SaveImage(IFormFile file)
        {
            string fileName = Path.GetFileName(file.FileName);
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), @"wwwroot/Img", fileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyTo(stream);
            }
        }

        // Update_SP_State he method to change the state of the product
        public ActionResult Update_SP_State(int id, string type)
        {
            try
            {
                Commodity com = db.Commodity.Find(id);
                if (type == "上")
                {
                    com.Cstate = "已上架";
                }
                else
                {
                    com.Cstate = "未上架";
                }
                db.SaveChanges();
                return Content("true");
            }
            catch (Exception)
            {
                return Content("false");
                throw;
            }
        }

        // Modify the commodity method
        public ActionResult Update_Commodity_Info(int id)
        {
            ViewBag.list = db.Commodity.Find(id);
            ViewBag.producttype = db.ProductType.ToList();
            return View();
        }
        [HttpPost]
        public ActionResult Update_Commodity_Info(Commodity com, IFormFile img)
        {
            try
            {

                if (img != null)
                {
                    com.Cimg = "/Img/" + img.FileName;
                    SaveImage(img);
                }
                db.Commodity.Update(com);
                db.SaveChanges();
                ViewBag.list = com;
                ViewData["msg"] = "ok";
                ViewBag.producttype = db.ProductType.ToList();
            }
            catch (Exception)
            {
                ViewData["msg"] = "no";
                throw;
            }
            return View();
        }

        //Delete the product method
        public ActionResult DelCommodity(int id)
        {
            try
            {
                Commodity com = db.Commodity.Find(id);
                db.Commodity.Remove(com);
                db.SaveChanges();
                return Content("true");
            }
            catch (Exception)
            {
                return Content("false");
                throw;
            }
        }
        // The administrator's purchase history page
        public ActionResult ManageOrder(int? oid)
        {
            //int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // Get userid

            List<Orderhistory> list_order = db.Orderhistory.ToList(); //Get all orders for the user

            List<Historicalorders> list_historder = db.Historicalorders.ToList(); //get all orders purchased by the user

            if (oid != null) // ot equal to NULL means a value was passed in and we have to do the next step
            {
                list_historder = db.Historicalorders.Where(hh => hh.Oid == oid).ToList();
            }

            ViewBag.list_order = list_order.OrderByDescending(oo => oo.Odate).ToList();
            ViewBag.list_historder = list_historder;

            return View();
        }

        // The administrator shipping function
        public ActionResult Fh(int id)
        {
            try
            {
                Orderhistory orderhistory = db.Orderhistory.Find(id);
                orderhistory.Ostate = "已发货";
                db.SaveChanges();
                return Content("ok");
            }
            catch (Exception)
            {
                return Content("no");
                throw;
            }

        }
        // Employee Management
        public ActionResult Employeemanagement(string name, int PageIndex = 1, int PageSize = 5)
        {
            var Result = db.UserInfo.Where(nn => nn.Identitys == "员工").ToList();
            //Save paging data to the page
            int TotalRows = Result.Count();
            if (name != null && name != "")
            {
                Result = Result.Where(nn => nn.FullName.Contains(name))
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return a specified number of results
               .ToList();
                //Save paging data to the page
                TotalRows = Result.Count();
            }
            else
            {
                Result = Result
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return a specified number of results
               .ToList();
            }

            ViewBag.PageIndex = PageIndex;
            ViewBag.PageSize = PageSize;
            ViewBag.TotalRows = TotalRows;
            ViewBag.TotalPage = Math.Ceiling(TotalRows * 1.0 / PageSize);

            ViewBag.list = Result;
            return View();
        }
        public ArrayList zhou_list = new ArrayList()
            { "New South Wales (NSW)", "Victoria (VIC)", "Queensland (QLD)",
            "QueenslanWestern Australia (WA)","South Australia (SA)","Tasmania (TAS)","Callaghan(NsW)"};
        // Add new users including customers, employees, and administrators
        public ActionResult Addauser()
        {
            ViewBag.zhou_list = zhou_list;

            return View();
        }
        [HttpPost]
        public ActionResult Addauser(string add1, string add2, string add3, UserInfo user)
        {
            user.Addresss = add1 + "," + add2 + "," + add3 + ",Australia";
            user.FullName = user.FirstName + " " + user.LastName;
            db.UserInfo.Add(user);
            db.SaveChanges();
            ViewData["msg"] = "ok";
            ViewBag.zhou_list = zhou_list;
            return View();
        }

        // PersonalInformation PersonalInformation page
        public ActionResult PersonalInformation(string add1, string add2, string add3, UserInfo temp_user)
        {
            if (HttpContext.Session.GetString("userid") == null)
            {
                return Redirect("/Login/Login");
            }

            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // get userid

            if (add1 != null)
            {
                UserInfo user = db.UserInfo.Find(userid);
                user.Addresss = add1 + "," + add2 + "," + add3 + ",Australia";
                user.FullName = temp_user.FirstName + " " + temp_user.LastName;
                user.FirstName = temp_user.FirstName;
                user.LastName = temp_user.LastName;
                user.Email = temp_user.Email;

                db.SaveChanges();
                ViewData["msg"] = "ok";
            }

            ViewBag.user = db.UserInfo.Find(userid); // Get user info
            ViewBag.zhou_list = zhou_list;

            return View();
        }
        public ActionResult UpdatePassword()
        {
            ViewData["msg"] = "null";
            return View();
        }
        [HttpPost]
        public ActionResult UpdatePassword(string pwd1, string pwd2)
        {
            if (pwd1 != pwd2)
            {
                ViewData["msg"] = "no";
                return View();
            }
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // Get the user id
            UserInfo user = db.UserInfo.Find(userid);
            user.PassWords = pwd1;
            db.SaveChanges();
            ViewData["msg"] = "ok";
            return View();
        }
        //  Methods to save user ids In order to modify the user's information, the ids should be preserved
        public ActionResult Save_User_id(int id)
        {
            HttpContext.Session.SetString("updateuserid", id.ToString());
            return Redirect("/Manage/Update_User");
        }
        public ActionResult Update_User(string add1, string add2, string add3, UserInfo temp_user)
        {
            int userid = int.Parse(HttpContext.Session.GetString("updateuserid").ToString());

            if (add1 != null)
            {
                UserInfo user = db.UserInfo.Find(userid);
                user.Addresss = add1 + "," + add2 + "," + add3 + ",Australia";
                user.FullName = temp_user.FirstName + " " + temp_user.LastName;
                user.FirstName = temp_user.FirstName;
                user.LastName = temp_user.LastName;
                user.Email = temp_user.Email;

                db.SaveChanges();
                ViewData["msg"] = "ok";
            }

            ViewBag.user = db.UserInfo.Find(userid); // Get user info
            ViewBag.zhou_list = zhou_list;
            return View();
        }
        // Customer management
        public ActionResult Usermanagement(string name, int PageIndex = 1, int PageSize = 5)
        {
            var Result = db.UserInfo.Where(nn => nn.Identitys == "顾客").ToList();
            //Save paging data to the page
            int TotalRows = Result.Count();
            if (name != null && name != "")
            {
                Result = Result.Where(nn => nn.FullName.Contains(name))
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) //  return the specified number of results
               .ToList();
                //Save paging data to the page
                TotalRows = Result.Count();
            }
            else
            {
                Result = Result
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) //  return the specified number of results
               .ToList();
            }

            ViewBag.PageIndex = PageIndex;
            ViewBag.PageSize = PageSize;
            ViewBag.TotalRows = TotalRows;
            ViewBag.TotalPage = Math.Ceiling(TotalRows * 1.0 / PageSize);

            ViewBag.list = Result;
            return View();
        }
        // Methods for deleting customers
        public ActionResult Delete_User(int id)
        {
            try
            {
                UserInfo com = db.UserInfo.Find(id);
                db.UserInfo.Remove(com);
                db.SaveChanges();
                return Content("true");
            }
            catch (Exception)
            {
                return Content("false");
                throw;
            }
        }
        //  Adminmanagement
        public ActionResult Adminmanagement(string name, int PageIndex = 1, int PageSize = 5)
        {
            var Result = db.UserInfo.Where(nn => nn.Identitys == "管理员").ToList();
            //Save paging data to the page
            int TotalRows = Result.Count();
            if (name != null && name != "")
            {
                Result = Result.Where(nn => nn.FullName.Contains(name))
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return the specified number of results
               .ToList();
                //Save paging data to the page
                TotalRows = Result.Count();
            }
            else
            {
                Result = Result
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return the specified number of results
               .ToList();
            }

            ViewBag.PageIndex = PageIndex;
            ViewBag.PageSize = PageSize;
            ViewBag.TotalRows = TotalRows;
            ViewBag.TotalPage = Math.Ceiling(TotalRows * 1.0 / PageSize);

            ViewBag.list = Result;
            return View();
        }
        // Product type management
        public ActionResult Producttypemanagement()
        {
            ViewBag.list = db.ProductType.ToList();
            return View();
        }
        public ActionResult inserttype(string text)
        {
            ProductType bookType = new ProductType();
            bookType.PName = text;
            db.ProductType.Add(bookType);
            db.SaveChanges();
            return RedirectToAction("Producttypemanagement");
        }
        // Delete the type of
        public ActionResult deltype(int id)
        {
            ProductType bookType = db.ProductType.Find(id);
            db.ProductType.Remove(bookType);
            db.SaveChanges();
            return RedirectToAction("Producttypemanagement");
        }

        //  Returning the book 
        public ActionResult HS(int id)
        {
            Historicalorders historicalorders = db.Historicalorders.Find(id);
            historicalorders.Bookreturntime = DateTime.Now;
            historicalorders.Hprice = 2; // Equals 2 for returned books 1 for borrowed books
            db.SaveChanges();
            return Content("ok");
        }

        // Return all books for this order
        public ActionResult Allreturned(int id)
        {
            var historicalorders = db.Historicalorders.Where(x => x.Oid == id).ToList();
            var datetime_now = DateTime.Now;
            foreach (var item in historicalorders)
            {
                item.Bookreturntime = datetime_now;
                item.Hprice = 2;
            }
            db.SaveChanges();
            return Content("ok");
        }
    }
}
