﻿using JoyfulHome.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace JoyfulHome.Controllers
{
    public class LoginController : Controller
    {
        private FreshliveContext db;
        public LoginController(FreshliveContext _db)
        {
            db = _db;
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string login_uid, string login_pwd,string type)
        {
            UserInfo user = db.UserInfo.Where(uu => uu.Email.Trim() == login_uid && uu.PassWords.Trim() == login_pwd && uu.Identitys == type).FirstOrDefault();
            if (user == null)
            {
                return Content("Error");
            }
            else
            {
                HttpContext.Session.SetString("userid", user.Id.ToString());
                return Content("true");
            }
        }
        [HttpPost]
        public IActionResult Regist(UserInfo user)
        {
            try
            {
                user.Identitys = "customer";
                db.UserInfo.Add(user);
                db.SaveChanges();
                return Content("true");
            }
            catch (System.Exception)
            {
                return Content("false");
                throw;
            }
        }
    }
}
