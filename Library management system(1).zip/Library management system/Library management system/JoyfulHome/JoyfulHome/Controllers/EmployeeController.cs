﻿using JoyfulHome.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System;
using Microsoft.AspNetCore.Http;
using System.Collections;

namespace JoyfulHome.Controllers
{
    public class EmployeeController : Controller
    {
        private FreshliveContext db;
        public EmployeeController(FreshliveContext _db)
        {
            db = _db;
        }
        public IActionResult Index(string name, int PageIndex = 1, int PageSize = 5) // Product Management Page
        {
            var Result = db.Commodity.Where(nn => nn.Cname.Contains(name)).ToList();
            //Save paging data to the page
            int TotalRows = db.Commodity.Count();
            if (name != null && name != "")
            {
                Result = Result
               .OrderBy(a => a.Id) //ordering criteria
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) //  return the specified number of results
               .ToList();
                //Save paging data to the page
                TotalRows = Result.Count();
            }
            else
            {
                Result = db.Commodity
               .OrderBy(a => a.Id) // sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) //  return the specified number of results
               .ToList();
            }

            ViewBag.PageIndex = PageIndex;
            ViewBag.PageSize = PageSize;
            ViewBag.TotalRows = TotalRows;
            ViewBag.TotalPage = Math.Ceiling(TotalRows * 1.0 / PageSize);

            ViewBag.list = Result;
            return View();
        }
        // Customer display
        public ActionResult Index2(string name, int PageIndex = 1, int PageSize = 5)
        {
            var Result = db.UserInfo.Where(nn => nn.Identitys == "顾客").ToList();
            // Save paging data to page
            int TotalRows = Result.Count();
            if (name != null && name != "")
            {
                Result = Result.Where(nn => nn.FullName.Contains(name))
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return the specified number of results
               .ToList();
                // Save paging data to page
                TotalRows = Result.Count();
            }
            else
            {
                Result = Result
               .OrderBy(a => a.Id) //sort condition
               .Skip((PageIndex - 1) * PageSize)//filter the first N results
               .Take(PageSize) // return the specified number of results
               .ToList();
            }

            ViewBag.PageIndex = PageIndex;
            ViewBag.PageSize = PageSize;
            ViewBag.TotalRows = TotalRows;
            ViewBag.TotalPage = Math.Ceiling(TotalRows * 1.0 / PageSize);

            ViewBag.list = Result;
            return View();
        }
        public ArrayList zhou_list = new ArrayList()
            { "New South Wales (NSW)", "Victoria (VIC)", "Queensland (QLD)",
            "QueenslanWestern Australia (WA)","South Australia (SA)","Tasmania (TAS)","Callaghan(NsW)"};
        // PersonalInformation PersonalInformation page
        public ActionResult PersonalInformation(string add1, string add2, string add3, UserInfo temp_user)
        {
            if (HttpContext.Session.GetString("userid") == null)
            {
                return Redirect("/Login/Login");
            }

            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // get userid

            if (add1 != null)
            {
                UserInfo user = db.UserInfo.Find(userid);
                user.Addresss = add1 + "," + add2 + "," + add3 + ",Australia";
                user.FullName = temp_user.FirstName + " " + temp_user.LastName;
                user.FirstName = temp_user.FirstName;
                user.LastName = temp_user.LastName;
                user.Email = temp_user.Email;

                db.SaveChanges();
                ViewData["msg"] = "ok";
            }

            ViewBag.user = db.UserInfo.Find(userid); // Get user info 
            ViewBag.zhou_list = zhou_list;

            return View();
        }
        public ActionResult UpdatePassword()
        {
            ViewData["msg"] = "null";
            return View();
        }
        [HttpPost]
        public ActionResult UpdatePassword(string pwd1, string pwd2)
        {
            if (pwd1 != pwd2)
            {
                ViewData["msg"] = "no";
                return View();
            }
            int userid = int.Parse(HttpContext.Session.GetString("userid").ToString()); // Get user info 
            UserInfo user = db.UserInfo.Find(userid);
            user.PassWords = pwd1;
            db.SaveChanges();
            ViewData["msg"] = "ok";
            return View();
        }
    }
}
